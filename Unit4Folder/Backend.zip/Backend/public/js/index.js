function next(){
    window.location.href="../../views/studentlogin.ejs"
}
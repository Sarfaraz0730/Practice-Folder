const mongoose = require("mongoose");

const bcrypt = require("bycrptjs")

const userSchema = new mongoose.Schema({
    // crate user schema 
    // there are many field in web site but i am taking on one email and password

    email : {type :String,required:true, unique:true},
    password:{ type:String , required:true},

},
{
    versionKey :false,
    timestamps:true,
});

userSchema.pre("save" , (next) =>{

    if(!this.isModify("password")) return next ()

    bcrypt.hash('bacon', 8, function(err, hash) {
        if(err) return next(err);

        userSchema.password = hash;
    });
})

module.exports = mongoose.model("user", userSchema);
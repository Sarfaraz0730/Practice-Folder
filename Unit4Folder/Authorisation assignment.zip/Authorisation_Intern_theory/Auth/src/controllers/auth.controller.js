const mongoose = require("mongoose")
const User = require("../models/user.model")
const register = async(req,res) =>{
try{

    //first check if the email provided is already given to  user
 let user = await User.findOne({email:res.body.email}).lean().exec();

 // if yes then throw an error 404 Bad request
 if(user)
 return res.status(400).send({message : "User with the email already exist"})

 // if not then we will create  the user
 // we will hash the password for the user
 
 user = await User.create(req.body)











 
} catch(err){

    return res.status(500).send({message : err.message})

}





// we wilol create for the user


// return the token and send the user







    return res.send("Register")
}


const login= async(req,res) =>{
    
    return res.send("Login")
}

module.exports = {register, login}